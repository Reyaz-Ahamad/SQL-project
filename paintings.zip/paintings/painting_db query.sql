create database painting_db;
use painting_db;


-- 1. Fetch all the paintings which are not displayed on any museums?

select * from work;
select * from work 
where museum_id is null;


-- 2. Are there museums without any paintings?

select * from museum m
where not exists (select 1 from work w
where w.museum_id=m.museum_id);
 
--  3. How many paintings have an asking price of more than their regular price?

select name, sale_price, regular_price from work
join product_size on work.work_id = product_size.work_id
where sale_price > regular_price; 

-- 4. Identify the paintings whose asking price is less than 50% of its regular price

select * from product_size
join work on work.work_id = product_size.work_id
where sale_price < 1/2 * regular_price;

-- 5. Which canva size costs the most?

select * from product_size;
select work_id, size_id, max(regular_price) as max from product_size
group by work_id, size_id
order by max desc
limit 1;

-- 6. Delete duplicate records from work, product_size, subject and image_link tables

select count(distinct(work_id)) from work;
select count(style) from work;
select * from work;


-- 7. Identify the museums with invalid city information in the given dataset

-- select city from museu-- m;
-- where city ~ '^[0-9]';


-- 8. Museum_Hours table has 1 invalid entry. Identify it and remove it.

select * from Museum_Hours;

select museum_id, day,count(*)
from museum_Hours
group by museum_id,day
having count(*)>1;


-- 9. Fetch the top 10 most famous painting subject

select * from subject;
select subject, count(*) as count  from subject
group by subject
order by count desc
limit 10;


-- 10. Identify the museums which are open on both Sunday and Monday. Display
-- museum name, city.

SELECT DISTINCT m.name, m.city
FROM museum m
JOIN museum_hours mh1 ON m.museum_id = mh1.museum_id
JOIN museum_hours mh2 ON m.museum_id = mh2.museum_id
WHERE mh1.day = 'Sunday' AND mh2.day = 'Monday';


-- 11. How many museums are open every single day?


select museum_hours.museum_id, count(museum_hours.museum_id)as count from museum_hours
join museum on museum.museum_id = museum_hours.museum_id
group by museum_hours.museum_id
having count = 7;


